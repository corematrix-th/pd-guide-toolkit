

PD Guide Toolkit v4.8.3
- Improved Smart Dispatch Rule: dispatch only one part; no multi-part conclusions.
- Removed Thermal Module from Fan logic.
- Added Not Tested to Check Task Manager Usage.
- Improved Email TH rules: customer result request appears only at the final closing line.
- Safer fallback: multi-part default conclusions now become Blank Result instead of dispatching multiple parts.
# PD Guide Toolkit - Development Rules

Version: 4.7.9

## Project workflow
- Treat user requests for a future version as backlog only.
- Create a new ZIP only when the user explicitly asks to make/build a specific version.
- Version names must use only the version number. Do not add suffixes such as Update or Final.
- ZIP name, root folder name, and UI version must match.

## Protected sections
- Do not modify Error Code or Troubleshooting Guide unless the user explicitly authorizes it.
- For v4.7.9, Error Code Description and BIOS/Supervisor Password Description are authorized.

## Product structure
- Dock category must exist only under ThinkPad.
- Other product lines must not show Dock.
- Use AIO instead of All in One.

## Checklist design
- Use existing checklist items by default. Do not invent items unless the user explicitly requests an addition.
- Order checklist items by real troubleshooting workflow and dependency, not by rigid category only.
- Keep related items together, such as Device Manager -> Uninstall Driver -> Driver Update.
- Windows-based checks should generally come before restart/BIOS-heavy checks when appropriate.
- Physical damage / Liquid spilled must be before Other issue.
- Other issue must be the last checklist item.

## Naming standards
- Use device-specific driver labels: <Device> Driver Update.
- Do not use generic Driver Update.
- Use Swap <Device> for swapping with another known-good device.
- Use <Device> test on other machine when testing the same device on another system.
- Do not add unnecessary External wording to checklist labels when product context is clear.
- Standardize terminology/capitalization, for example: USB Device, Power Cord, DisplayPort, USB-C cable, Audio Jack.

## Reset terminology
- ThinkPad uses Power Reset / Emergency Reset.
- Other product lines use Power Reset only.
- Do not use the removed power-discharge checklist wording.

## Swap eligibility
- Notebook internal keyboards should not use Swap Keyboard; use USB Keyboard test / external keyboard verification instead.
- Desktop/AIO keyboards may use Swap Keyboard because they are external devices.
- Apply swap only when the device is realistic to swap during field/customer troubleshooting.

## FRU P/N
- Request FRU P/N only for optional external accessories when appropriate: Adapter, Power Cord, External Keyboard, External Mouse.
- Do not request FRU P/N for internal FRUs unless the user explicitly requests it.

## Conclusion UI
- Conclusion displays Result and Part only.
- Do not show Recommendation in the CONCLUSION panel.


## Documentation Structure
- Project documentation files must be stored only inside `docs/` (DEVELOPMENT_RULES.md, CHANGELOG.md, TODO.md). Do not duplicate `.md` files at project root.

## Website Counter
- Site statistics use a non-resetting global counter for the whole toolkit, not per version. Store stats under a stable Firebase path such as `siteStats/global`. Display below the Version text in the format: `👥 <Visitors> | 🟢 <Online>`.

## Lenovo Diagnostics Guide
- Windows available: Lenovo Commercial Vantage / Lenovo Vantage → Device diagnostics → Hardware scan → Quick Scan.
- Windows unavailable: press F10 repeatedly during startup → Run All → Quick → Quick Unattended.
- IdeaPad some models: Novo Button → UEFI Diagnostics → Run All → Quick → Quick Unattended.


## v4.8.6 Smart Review / Backup Rules

### Smart Review Engine
- CONCLUSION must show only two lines: `Result` and `Part`.
- If checklist data is inconsistent, set `Result : Verify Checklist` and `Part : -`.
- RESULT / EMAIL must keep the checklist summary at the top, then show a compact `Review` block below.
- Multiple conflicts must be merged into one Review block. Do not repeat the same header/footer for each conflict.
- Review conflict format:
  - `• Item A = Value`
  - `  ↔ Item B = Value`
- End Review blocks with `Please verify with the customer.` only. Do not show `(No email generated)`.

### Backup Rule
- Keep only the previous version backup in `backup/`.
- Do not store backup folders for every version unless explicitly requested.

### Generate Note vs Email Rule
- Generate Note uses selected checklist answers, Smart Review, and Dispatch Logic.
- Email TH / Email EN are customer troubleshooting templates for the selected symptom.
- Email TH / Email EN must be generated normally even when Generate Note result is `Verify Checklist`.
- Email TH / Email EN must include all checklist steps for that symptom and must not depend on selected dropdown answers.

### Packaging Rule
- Every ZIP must contain one root folder named exactly like the ZIP/version, for example `PD_Guide_Toolkit_v4_8_6/`.
- Do not place project files directly at the ZIP root. This prevents files from scattering when extracted.

## v4.8.6 Conclusion / Suggestion Display Rule
- CONCLUSION panel displays `Result` and `Part` only.
- RESULT / EMAIL must not repeat `Result :` and `Part :`.
- Normal cases show only one line: `Conclusion: Dispatch <Part>` or `Conclusion: FOP`.
- Suggested PD is hidden in normal Dispatch/FOP cases.
- Suggestion appears only when the selected symptom is incorrect or information is inconsistent.
- Symptom recommendations must use arrow format: `Level 1 → Symptom`.


## v4.8.9 Generate Note Rules

- Checklist lines use lowercase by default.
- Technical terms remain uppercase / proper case, including AC, DC, SSD, HDD, RAM, USB, BIOS, UEFI, TPM, LAN, WLAN, WWAN, HDMI, DP, Type-C, PD, LED, Intel, AMD, NVIDIA, Lenovo Vantage, Lenovo Diagnostics, FRU P/N.
- FRU P/N value is always uppercase.
- Symptom title and Conclusion keep the existing format.
- ThinkPad Power Reset and Emergency Reset must be separate checklist items and stay adjacent, Power Reset first.
- Software / Driver / BIOS update checklist order is Lenovo Vantage update, XXX driver update, BIOS update. Status values are done / not test.


## v4.8.9 Reference Text Master Rule
- The toolkit must include a `Reference_Text/` folder in every future ZIP release.
- The fixed product model list is exactly: ThinkPad, IdeaPad, ThinkCentre Desktop, ThinkCentre Tiny, AIO.
- The files in `Reference_Text/` are the master reference for Level 1 and Symptom order.
- If any future version adds, removes, renames, or reorders a Level 1 or Symptom, update both the toolkit logic and the corresponding text file in `Reference_Text/`.
- `Power on no display + legacy Beep wording` must not be used going forward. Use `Power on no display + Beep Sound` for all models and reuse the existing Beep checklist logic.
- Existing symptoms must keep their original checklist, validation, dispatch, Suggested PD, RESULT / EMAIL, and Conclusion behavior unless explicitly changed by the user.
- New symptoms should clone the closest existing checklist pattern and follow all existing dispatch and RESULT / EMAIL rules.


## v4.9.1 Rules
- Device Manager checklist labels must use `Check <Device Name> in Device Manager`.
- Device Manager check must appear before the related `Uninstall <Device Name> Driver and Restart` item.
- Use `Power on no display + Beep Sound`; do not use `Beep code`.
- ThinkPad / IdeaPad / AIO must not show the `Monitor` level.
- ThinkCentre Desktop and ThinkCentre Tiny may show the `Monitor` level.
- ThinkCentre Tiny `No power` must not include `Swap Power Outlet` or `Swap PSU`; use `Swap AC Power Cord`.
- ThinkCentre Tiny keyboard symptoms must include the existing `FRU P/N` component.
- Front Audio Jack and Rear Audio Jack must include `Swap Audio Jack Port`.
- TIO Dock `Not charging / No power to Tiny` must include `Test Tiny without TIO Dock`.
- Reference_Text must be updated together with Toolkit model/symptom changes.

- v4.9.1 hotfix: standalone checklist label "Camera" must not be used; replace with "Check Camera in Device Manager". Device Manager camera check remains "Check Camera in Device Manager".


## File Naming Rule

When modifying an existing version without changing the version number:

- The output filename MUST remain exactly the same as the input filename.
- Never append fixed, final, new, updated, rev, revision, edit, patch, or any other suffix.
- The filename changes only when the user explicitly requests a new version.

Example:
- Input: `PD_Guide_Toolkit_v4_9_0.zip`
- Output: `PD_Guide_Toolkit_v4_9_0.zip`

## Model & Symptom Validation Rule

Before creating or modifying any troubleshooting checklist, validate all of the following:

1. Product Model
2. Symptom
3. Hardware architecture
4. Port / Interface
5. Connection method
6. Driver / Device
7. Replaceable component

Every checklist item MUST be technically relevant to both the selected Model and the selected Symptom.

Do NOT reuse a checklist from another model or symptom without validating every troubleshooting step.

Examples:
- USB-C Display → Swap USB-C cable
- HDMI → Swap HDMI cable
- DisplayPort → Swap DisplayPort cable
- VGA → Swap VGA cable
- USB-A → Swap USB Device
- Audio Jack → Swap Audio Jack Port / Audio Device

When a checklist is modified, review every troubleshooting item in that checklist and remove any item that is not technically applicable to the selected model or symptom.

## Full Audit Release Rule

When the user requests **Full Audit**, the toolkit must be checked across the whole project before release, not only the reported symptom.

Required audit scope:
- Check every affected Product Model.
- Check every affected Level 1 and Symptom.
- Check every troubleshooting checklist item against the selected Model and Symptom.
- Ensure port/interface wording matches the symptom:
  - USB-C Display → Swap USB-C cable
  - HDMI → Swap HDMI cable
  - DisplayPort → Swap DisplayPort cable
  - VGA → Swap VGA cable
- Generic display-port troubleshooting should use **Swap Monitor** instead of unclear wording such as **External Monitor test** when the intent is to test with another monitor.
- Do not release a version while any checklist item still conflicts with the Model & Symptom Validation Rule.

## File Naming Rule

When modifying an existing version without changing the version number, the output filename must remain exactly the same as the input filename.

Do not append suffixes such as fixed, final, new, updated, rev, revision, edit, patch, or any other suffix.

## v4.9.3 Full Project Audit Rule

Before every version release, perform a Full Project Audit.
Do not modify only the requested checklist.
Review all related checklists, all affected models, and all affected symptoms to ensure consistency across the toolkit.
A version must not be released until the audit is complete.

## v4.9.3 Standard Troubleshooting Workflow Rule

All troubleshooting checklists must follow `docs/STANDARD_WORKFLOW.md`.
A checklist does not need to contain every workflow item, but any item included must follow the relative order defined in the workflow.

## v4.9.3 FRU P/N Placement Rule

`FRU P/N` must always be placed at the end of the troubleshooting checklist when present.
It must never appear at the top or in the middle of troubleshooting steps.

## v4.9.3 No Power Adapter Rule

For `No power`, if the checklist contains `Swap Adapter` or `Swap AC Adapter`, do not also include `Swap AC Power Cord`.

## v4.9.3 ThinkPad Reset Rule

For ThinkPad, `Emergency Reset` may appear only in:

- Boot > No power
- Boot > Power on no display
- Boot > Power on no display + Beep Sound

For all other ThinkPad symptoms, use only `Power Reset` when a reset is applicable.

## v4.9.3 External Mouse / Keyboard Rule

Do not add external mouse or external keyboard tests unless the selected symptom is directly about the external mouse or external keyboard itself.

## Power Reset Matrix Rule

`docs/POWER_RESET_MATRIX.md` is the source of truth for where `Power Reset` and `Emergency Reset` may appear.

Before every version release, run a Full Project Audit against the matrix:

- Add `Power Reset` to every required symptom listed in `POWER_RESET_MATRIX.md`.
- Remove `Power Reset` from every symptom not listed in the matrix.
- Keep `Emergency Reset` only for ThinkPad Boot symptoms:
  - No power
  - Power on no display
  - Power on no display + Beep Sound
- Do not include `Emergency Reset` in any other checklist.
- Follow Standard Troubleshooting Workflow placement when inserting reset items.



## Full Project Audit Release Rule

Before every version release, perform a Full Project Audit.

- Do not modify only the requested checklist.
- Review all related checklists, affected models, and affected symptoms.
- Review all rules in `docs/` and confirm they were applied to the Toolkit data.
- A version must not be released until the audit is complete.

## Power Reset Matrix Rule

`docs/POWER_RESET_MATRIX.md` is the source of truth for `Power Reset` and `Emergency Reset` placement.

- If a symptom is listed in `POWER_RESET_MATRIX.md`, it must contain `Power Reset`.
- If a symptom is not listed in `POWER_RESET_MATRIX.md`, it must not contain `Power Reset`.
- ThinkPad `Emergency Reset` is allowed only for No power, Power on no display, and Power on no display + Beep Sound.

## Event Viewer / Dump File Placement Rule

When `Event Viewer / Dump file collected` is used, it must be placed after `Re-install Windows` and before `Physical damage / Liquid spilled`.

## FRU P/N Placement Rule

`FRU P/N` must always be the final checklist item, after `Other issue` and after any Event Viewer / Dump file item.


## v4.9.3 Email Writing Rule

Customer emails must follow `docs/EMAIL_RULES.md`. Email TH / EN must be concise, customer-friendly, and generated from checklist items in the same order. Do not copy checklist labels directly. Do not include internal dropdown values. Always use the standard Thai closing message.

## v4.9.3 Full Audit Requirement

Before release, audit all checklist ordering, Power Reset Matrix, Emergency Reset placement, Event Viewer / Dump file placement, FRU P/N placement, Device Manager wording, and Email TH / EN mapping.

---

## Email Generation Rule (v4.9.3 Full Audit)

Email TH / Email EN must be generated from customer-facing instruction mapping, not raw checklist labels.

Rules:

- One checklist item becomes one customer instruction.
- Use short imperative sentences.
- Preserve the checklist order.
- Do not expose dropdown values such as Detect, Done, Same issue, Working, or Not tested.
- Do not include FRU P/N in customer email by default.
- Every Device Manager checklist must use the customer wording pattern: `ตรวจสอบว่า Device Manager พบอุปกรณ์ <Device Name> หรือไม่`.
- Swap instructions must use short wording such as `ทดสอบสลับด้วย Adapter อื่น`.
- Always include the standard closing message.
- Email rules are documented in `docs/EMAIL_RULES.md`.
- Preferred checklist-to-email mapping is documented in `docs/EMAIL_MAPPING.md`.

Before every version release, verify that Email TH and Email EN generate content for every symptom and do not output raw checklist labels when a mapped customer sentence exists.

## v4.9.4 Email / Evidence Rules

### Customer Email Rule

Email TH / Email EN must be customer-facing instructions, not raw checklist labels.

- One checklist item must map to one predefined customer instruction.
- Use short imperative wording.
- Preserve the checklist order.
- Do not expose internal terms such as FRU, Dispatch, FOP, Conclusion, Suggested PD, or internal engineering notes.
- Use the standard closing message for Email TH.

### Customer Action Type Rule

Every checklist item used for email generation should be classified as one of:

- Action
- Verify
- Update
- Send Photo
- Send Screenshot
- Send Video
- Send File
- Internal Only

Internal-only items must not be displayed in customer emails.

### Evidence Request Rule

Only request evidence when it has diagnostic value.

Do not request screenshots or photos for routine troubleshooting steps:

- Windows Update
- Lenovo Vantage Update
- BIOS Update
- Driver Update
- Power Reset
- Emergency Reset
- Swap Test
- Re-install Windows

Use `REQUEST_MAPPING.md` as the source of truth for evidence type and priority.

### Device Manager Email Rule

For `Check <Device> in Device Manager`, use this TH pattern:

```text
ตรวจสอบว่า Device Manager พบอุปกรณ์ <Device> หรือไม่
โดยเปิด Device Manager > <Category>
```

Do not describe every click. Specify only the relevant Device Manager category.

### Reset Email Wording Rule

Use these exact TH mappings:

```text
Emergency Reset
=> ทดสอบ Emergency Reset โดยกดรูใต้เครื่องค้างไว้ 5–10 วินาที จากนั้นทดลองเปิดเครื่องอีกครั้ง

Power Reset
=> ทดสอบ Power Reset โดยกดปุ่มเปิด/ปิดเครื่องค้างไว้ 10–15 วินาที จากนั้นตรวจสอบอาการอีกครั้ง
```

### FRU Customer Email Rule

Do not ask customers for FRU P/N.
If part identification is needed, request a photo instead:

```text
รบกวนส่งภาพถ่ายสติกเกอร์ Serial Number / MTM ที่อยู่ใต้เครื่องหรือด้านหลังเครื่อง
```


## v4.9.6 Global Mapping Maintenance Rule

- `Mapping.txt` is the source of truth for reusable checklist action wording.
- Every release ZIP must contain `Mapping.txt` at the root and `Reference_Text/Mapping.txt`.
- Runtime must include the same mapping in `data.js` as `GLOBAL_CHECKLIST_MAPPING`.
- Any checklist label that exists in Mapping.txt must use the mapped wording for Email TH / Email EN / action guidance.
- When a new mapping is added, update Mapping.txt, Reference_Text/Mapping.txt, `GLOBAL_CHECKLIST_MAPPING`, `docs/GLOBAL_CHECKLIST_MAPPING.md`, and run full checklist audit before release.
- Audit must check duplicate labels, missing mapping, wrong model checklist, Power Reset / Emergency Reset placement, Event Viewer / Dump file placement, and FRU P/N final placement.


## v4.9.6 Mapping Email Refactor Audit
- Added missing checklist labels into Mapping.txt and Reference_Text/Mapping.txt.
- Total runtime mapping entries: 246.
- Email TH and Email EN now call GLOBAL_CHECKLIST_MAPPING first before fallback rules.
- Verified Power LED / Charge LED / Adapter / Reset email text uses Mapping.txt wording instead of hardcoded wording.

## v4.9.6 Diagnostics Model-Specific Mapping Patch
- Run Lenovo Diagnostics / Lenovo Diagnostics Storage / Lenovo Diagnostics Battery must render only the currently selected product model flow.
- IdeaPad uses Novo Button → UEFI Diagnostics → Run All → Quick.
- ThinkPad, ThinkCentre Desktop, ThinkCentre Tiny, and AIO use F10 → Run All → Quick → Quick Unattended.
- Email TH, Email EN, checklist-generated notes, copy guide, and related guide modal must not display all model instructions together.

