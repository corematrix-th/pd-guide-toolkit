# Full Audit v4.9.6

Date: 2026-07-04

## Package audit

- Root folder renamed to `PD_Guide_Toolkit_v4_9_6`.
- Visible UI version updated to `Version 4.9.6`.
- README updated to v4.9.6.
- `Mapping.txt` included at toolkit root.
- `Reference_Text/Mapping.txt` included.
- `docs/GLOBAL_CHECKLIST_MAPPING.md` added.

## Runtime mapping audit

- Imported Mapping.txt into `GLOBAL_CHECKLIST_MAPPING`.
- Added aliases for existing checklist labels that differ from Mapping.txt wording.
- Email/action fallback now checks `GLOBAL_CHECKLIST_MAPPING` when no specific mapping exists.

## Checklist audit performed

- Scanned checklist labels from `data.js`.
- Normalized duplicated/tail checklist labels in v4.9.6 audit function.
- Preserved FRU P/N as the last tail item.
- Preserved Event Viewer / Dump file collected before physical/other issue.
- Preserved existing Power Reset / Emergency Reset model rules from v4.9.3 and added v4.9.6 mapping metadata.

## Counts

- Approximate Level sections found: 19
- Approximate symptoms with defaultResult found: 100
- Unique checklist/action labels scanned: 221
- Mapping entries imported from Mapping.txt including aliases: 70

## Notes

Some checklist labels are intentionally model/symptom-specific and do not require a Mapping.txt entry yet, such as cable-specific swap items, device-specific driver updates, FRU P/N, and symptom-specific photo/video requests. When any of those become reusable global checklist items, add them to Mapping.txt and rerun this audit.

## Missing direct global mapping candidates

- Adapter test
- Adapter works with another cord
- Airplane Mode
- Another Router test
- Bluetooth toggle available
- Boot order checked
- CMOS battery / RTC check
- Can detect Wi-Fi signal
- Can login with another account
- Clean Cooling System
- Clean camera lens
- Clean scroll wheel
- Clean touchpad surface
- ClickPad enabled
- Customer knows password
- Disable Touchpad test
- Disable UEFI IPv4 / IPv6
- Driver / Firmware Update
- Driver / Windows Update
- Error photo provided
- External mic test
- FN & Ctrl Swap
- FN Lock checked
- Fingerprint setup in Windows Hello
- Freeze occurs
- Headphone test
- Input device selected correctly
- Input volume level checked
- Intel RST / Storage Driver loaded
- Issue happens on all apps
- Issue occurs all apps
- Key stuck / sunk
- Lenovo Diagnostics Storage
- Lenovo Hotkey Features update
- Lenovo Vantage setting
- Lock on leave setting enabled
- Mic mute checked
- Microphone enhancement disabled
- Move LCD lid
- Mute checked
- Network boot disabled
- Noise occurs all apps
- Novo Button
- Original Adapter used
- Output device selected correctly
- Password / PIN reset
- Pixel location confirmed
- Proof of ownership checked
- RTC battery / CMOS check
- SD Card test on other machine
- SIM card detected
- SIM detected
- SIM tray damage
- Safe Mode test
- Secure Boot disabled
- Set date and time in BIOS
- Storage Firmware Update
- Touchpad enabled in Settings
- TrackPoint enabled in BIOS
- Uninstall Bluetooth Driver and Restart
- Uninstall Fingerprint Driver and Restart
- Uninstall HID-compliant touch screen Driver and Restart
- Uninstall Wireless Driver and Restart
- Update Graphics Driver
- Voice Recorder
- Volume Mixer checked
- Volume level checked
- Wi-Fi test
- Windows Hello Face setup
- Windows Update


## v4.9.6 Mapping Email Refactor Audit
- Added missing checklist labels into Mapping.txt and Reference_Text/Mapping.txt.
- Total runtime mapping entries: 246.
- Email TH and Email EN now call GLOBAL_CHECKLIST_MAPPING first before fallback rules.
- Verified Power LED / Charge LED / Adapter / Reset email text uses Mapping.txt wording instead of hardcoded wording.
