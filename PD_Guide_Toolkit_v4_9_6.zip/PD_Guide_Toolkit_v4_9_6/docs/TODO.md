

PD Guide Toolkit v4.8.3
- Improved Smart Dispatch Rule: dispatch only one part; no multi-part conclusions.
- Removed Thermal Module from Fan logic.
- Added Not Tested to Check Task Manager Usage.
- Improved Email TH rules: customer result request appears only at the final closing line.
- Safer fallback: multi-part default conclusions now become Blank Result instead of dispatching multiple parts.
# TODO

- Continue standardizing Email TH wording across all symptoms when new checklist terms are added.


## Future Version Rule
- When new symptoms are added in later versions, update the matching Reference_Text file at the same time as the toolkit.
- Keep the five model names fixed unless the user explicitly changes them.


## v4.9.1 completed
- Applied agreed checklist and model structure standardization.

- v4.9.1 hotfix: standalone checklist label "Camera" must not be used; replace with "Check Camera in Device Manager". Device Manager camera check remains "Check Camera in Device Manager".

## v4.9.3 completed

- Full Project Audit rule added.
- Standard Workflow documentation added.
- FRU P/N placement rule applied.
- ThinkPad Emergency Reset scope limited.
- Port / cable checklist consistency reviewed and corrected for known display port symptoms.

## Audit Requirement

- Before releasing any future version, re-run the Full Project Audit against `docs/POWER_RESET_MATRIX.md` and `docs/STANDARD_WORKFLOW.md`.



## v4.9.3 completed

- Full Audit completed for checklist standardization and email writing rules.
- `EMAIL_RULES.md` added.

## Email Mapping Maintenance

- When adding a new checklist label, add or verify the matching customer-facing sentence in Email TH / EN mapping.
- Run Email Full Audit before each release to ensure no raw checklist labels appear in generated customer emails.

## After v4.9.4

- Continue expanding `EMAIL_MAPPING.md` until every checklist label has a predefined TH/EN customer instruction.
- Continue expanding `REQUEST_MAPPING.md` when new symptoms or evidence types are added.
- During every release, verify Email TH / EN output for representative symptoms from every model.


## v4.9.6 Global Mapping Maintenance Rule

- `Mapping.txt` is the source of truth for reusable checklist action wording.
- Every release ZIP must contain `Mapping.txt` at the root and `Reference_Text/Mapping.txt`.
- Runtime must include the same mapping in `data.js` as `GLOBAL_CHECKLIST_MAPPING`.
- Any checklist label that exists in Mapping.txt must use the mapped wording for Email TH / Email EN / action guidance.
- When a new mapping is added, update Mapping.txt, Reference_Text/Mapping.txt, `GLOBAL_CHECKLIST_MAPPING`, `docs/GLOBAL_CHECKLIST_MAPPING.md`, and run full checklist audit before release.
- Audit must check duplicate labels, missing mapping, wrong model checklist, Power Reset / Emergency Reset placement, Event Viewer / Dump file placement, and FRU P/N final placement.


## v4.9.6 Mapping Email Refactor Audit
- Added missing checklist labels into Mapping.txt and Reference_Text/Mapping.txt.
- Total runtime mapping entries: 246.
- Email TH and Email EN now call GLOBAL_CHECKLIST_MAPPING first before fallback rules.
- Verified Power LED / Charge LED / Adapter / Reset email text uses Mapping.txt wording instead of hardcoded wording.
