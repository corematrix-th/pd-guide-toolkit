# PD Guide Toolkit - Email Writing Rules

## Purpose

Email TH / Email EN must be written for customers, not engineers.
The email should clearly explain what the customer needs to do in short, friendly, actionable steps.

Do not copy raw troubleshooting checklist labels directly into the email.

---

## Email Structure

Every generated customer email must use this structure:

```text
เรียน คุณลูกค้า

รบกวนดำเนินการตามขั้นตอนด้านล่างนี้

1. <customer instruction>
2. <customer instruction>
3. <customer instruction>

หากดำเนินการเรียบร้อยแล้ว รบกวนแจ้งผลกลับ พร้อมแนบรูปหรือผลการทดสอบ (ถ้ามี) เพื่อให้ทางเราดำเนินการในขั้นตอนถัดไปครับ
```

For Email EN, use the same structure in English.

---

## Writing Style

- Use short imperative sentences.
- Explain only what the customer needs to do.
- Do not include long tutorials.
- Do not expose internal terms such as FRU, Dispatch, FOP, or Conclusion.
- Preserve the checklist order.
- One checklist item should become one customer-friendly instruction.

Good:

```text
ทดสอบสลับด้วย Adapter อื่น
```

Good:

```text
อัปเดต Windows ให้เป็นเวอร์ชันล่าสุด
```

Bad:

```text
Swap Adapter
```

Bad:

```text
Please perform the following technical troubleshooting checklist item.
```

---

## Instruction Detail Levels

### Level 1 - Simple Action

Use one short sentence for simple actions.

Examples:

```text
ทดสอบสลับด้วย Adapter อื่น
ทดสอบสลับด้วยสาย HDMI อื่น
อัปเดต Windows ให้เป็นเวอร์ชันล่าสุด
```

### Level 2 - Location Only

For Device Manager, Lenovo Vantage, or BIOS checks, tell the customer where to check.
Do not explain every click.

Example:

```text
ตรวจสอบว่า Device Manager พบอุปกรณ์ Camera หรือไม่
โดยเปิด Device Manager > Cameras
```

### Level 3 - Short How-To

Use a short method only when the customer may not know how to perform the action.

Examples:

```text
ทดสอบ Emergency Reset โดยกดรูใต้เครื่องค้างไว้ 5–10 วินาที จากนั้นทดลองเปิดเครื่องอีกครั้ง
```

```text
ทดสอบ Power Reset โดยกดปุ่มเปิด/ปิดเครื่องค้างไว้ 10–15 วินาที จากนั้นตรวจสอบอาการอีกครั้ง
```

```text
ทดสอบ Run Diagnostics
สำหรับ ThinkPad, ThinkCentre Desktop, ThinkCentre Tiny และ AIO: กด F10 รัว ๆ ขณะเปิดเครื่อง → เลือก Run All → Quick → Quick Unattended จากนั้นตรวจสอบว่า Pass หรือ Failed
สำหรับ IdeaPad: กด Novo Button → เลือก UEFI Diagnostics → Run All → Quick จากนั้นตรวจสอบว่า Pass หรือ Failed
```

---

## Device Manager Email Pattern

For every checklist item using this pattern:

```text
Check <Device Name> in Device Manager
```

Use this email format:

```text
ตรวจสอบว่า Device Manager พบอุปกรณ์ <Device Name> หรือไม่
โดยเปิด Device Manager > <Category>
```

Examples:

| Checklist | Email TH |
|---|---|
| Check Camera in Device Manager | ตรวจสอบว่า Device Manager พบอุปกรณ์ Camera หรือไม่\nโดยเปิด Device Manager > Cameras |
| Check Fingerprint Device in Device Manager | ตรวจสอบว่า Device Manager พบอุปกรณ์ Fingerprint หรือไม่\nโดยเปิด Device Manager > Biometric Devices |
| Check Wireless Driver in Device Manager | ตรวจสอบว่า Device Manager พบอุปกรณ์ Wireless หรือไม่\nโดยเปิด Device Manager > Network adapters |
| Check Bluetooth Device in Device Manager | ตรวจสอบว่า Device Manager พบอุปกรณ์ Bluetooth หรือไม่\nโดยเปิด Device Manager > Bluetooth |
| Check HID-compliant touch screen Driver in Device Manager | ตรวจสอบว่า Device Manager พบ HID-compliant touch screen หรือไม่\nโดยเปิด Device Manager > Human Interface Devices |

---

## Evidence Request Rule

Only request photos, screenshots, videos, or files when they provide diagnostic value.

Do not request screenshots for routine steps:

- Windows Update
- Lenovo Vantage Update
- BIOS Update
- Driver Update
- Power Reset
- Emergency Reset
- Swap Test
- Re-install Windows

The customer only needs to report the result unless evidence is specifically useful.

---

## FRU / Part Information Rule

Do not ask the customer for FRU P/N in the email.
Customers usually do not know what FRU means.

If part identification is needed, ask for a photo instead:

```text
รบกวนส่งภาพถ่ายสติกเกอร์ Serial Number / MTM ที่อยู่ใต้เครื่องหรือด้านหลังเครื่อง
```

---

## Customer Action Types

Every checklist mapping should define one action type:

- Action
- Verify
- Update
- Send Photo
- Send Screenshot
- Send Video
- Send File
- Internal Only

Internal-only items must not be displayed in customer emails.

Examples of internal-only items:

- Dispatch
- Conclusion
- Other issue
- Event Viewer / Dump file collected
- Dump File collected

---

## Standard Closing Message

Email TH must always end with:

```text
หากดำเนินการเรียบร้อยแล้ว รบกวนแจ้งผลกลับ พร้อมแนบรูปหรือผลการทดสอบ (ถ้ามี) เพื่อให้ทางเราดำเนินการในขั้นตอนถัดไปครับ
```
