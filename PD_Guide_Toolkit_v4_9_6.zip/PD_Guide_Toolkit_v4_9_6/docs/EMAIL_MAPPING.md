# PD Guide Toolkit - Email Mapping Reference

This file defines the preferred customer-facing wording for common checklist labels.

## Common Information

| Checklist | Email TH | Email EN |
|---|---|---|
| Power LED | ตรวจสอบว่าไฟ Power LED ติดหรือไม่ | Check whether the Power LED turns on. |
| Charge LED | ตรวจสอบว่าไฟ Charge LED ติดหรือไม่ | Check whether the Charge LED turns on. |
| Fan spinning | ตรวจสอบว่าพัดลมหมุนหรือไม่ | Check whether the fan spins. |
| Specific keys listed | ระบุปุ่มที่มีปัญหาให้ครบถ้วน | List all affected keys. |

## Device Manager

| Checklist | Email TH | Email EN |
|---|---|---|
| Check Camera in Device Manager | ตรวจสอบว่า Device Manager พบอุปกรณ์ Camera หรือไม่ | Check whether Device Manager detects the Camera device. |
| Check Fingerprint Device in Device Manager | ตรวจสอบว่า Device Manager พบอุปกรณ์ Fingerprint หรือไม่ | Check whether Device Manager detects the Fingerprint device. |
| Check HID-compliant touch screen Driver in Device Manager | ตรวจสอบว่า Device Manager พบ HID-compliant touch screen หรือไม่ | Check whether Device Manager detects HID-compliant touch screen. |
| Check Wireless Driver in Device Manager | ตรวจสอบว่า Device Manager พบอุปกรณ์ Wireless หรือไม่ | Check whether Device Manager detects the Wireless device. |
| Check Bluetooth Device in Device Manager | ตรวจสอบว่า Device Manager พบอุปกรณ์ Bluetooth หรือไม่ | Check whether Device Manager detects the Bluetooth device. |
| Check Audio Device in Device Manager | ตรวจสอบว่า Device Manager พบอุปกรณ์ Audio หรือไม่ | Check whether Device Manager detects the Audio device. |

## Driver

| Checklist | Email TH | Email EN |
|---|---|---|
| Uninstall Camera Driver and Restart | ถอนการติดตั้ง Driver ของ Camera แล้ว Restart เครื่อง | Uninstall the Camera driver and restart the machine. |
| Uninstall Wireless Driver and Restart | ถอนการติดตั้ง Driver ของ Wireless แล้ว Restart เครื่อง | Uninstall the Wireless driver and restart the machine. |
| Uninstall Audio Driver and Restart | ถอนการติดตั้ง Driver ของ Audio แล้ว Restart เครื่อง | Uninstall the Audio driver and restart the machine. |

## Update

| Checklist | Email TH | Email EN |
|---|---|---|
| Windows Update | อัปเดต Windows ให้เป็นเวอร์ชันล่าสุด | Update Windows to the latest version. |
| Lenovo Vantage Update | อัปเดต Driver และ BIOS ผ่าน Lenovo Vantage ให้เป็นเวอร์ชันล่าสุด | Update drivers and BIOS through Lenovo Vantage to the latest version. |
| BIOS Update | อัปเดต BIOS ให้เป็นเวอร์ชันล่าสุด | Update BIOS to the latest version. |
| Thunderbolt Driver Update | อัปเดต Thunderbolt Driver ให้เป็นเวอร์ชันล่าสุด | Update the Thunderbolt Driver to the latest version. |

## Swap

| Checklist | Email TH | Email EN |
|---|---|---|
| Swap Adapter | ทดสอบสลับด้วย Adapter อื่น | Try another Adapter. |
| Swap AC Adapter | ทดสอบสลับด้วย AC Adapter อื่น | Try another AC Adapter. |
| Swap USB-C Cable | ทดสอบสลับด้วยสาย USB-C อื่น | Try another USB-C cable. |
| Swap HDMI Cable | ทดสอบสลับด้วยสาย HDMI อื่น | Try another HDMI cable. |
| Swap DisplayPort Cable | ทดสอบสลับด้วยสาย DisplayPort อื่น | Try another DisplayPort cable. |
| Swap VGA Cable | ทดสอบสลับด้วยสาย VGA อื่น | Try another VGA cable. |
| Swap Monitor | ทดสอบสลับกับจอภาพอื่น | Try another monitor. |
| Swap RAM | ทดสอบสลับด้วย RAM อื่น | Try another RAM. |
| Swap SSD | ทดสอบสลับด้วย SSD อื่น | Try another SSD. |

## Reset / Diagnostics / OS

| Checklist | Email TH | Email EN |
|---|---|---|
| Power Reset | ทำ Power Reset แล้วทดสอบอาการอีกครั้ง | Perform Power Reset and test the issue again. |
| Emergency Reset | ทำ Emergency Reset แล้วทดลองเปิดเครื่องอีกครั้ง | Perform Emergency Reset and power on the machine again. |
| Run Lenovo Diagnostics | รัน Lenovo Diagnostics และแจ้งผลการทดสอบ | Run Lenovo Diagnostics and provide the test result. |
| Re-install Windows | ติดตั้ง Windows ใหม่แล้วทดสอบอาการอีกครั้ง | Re-install Windows and test the issue again. |

## Final Checks

| Checklist | Email TH | Email EN |
|---|---|---|
| Event Viewer / Dump file collected | เก็บข้อมูล Event Viewer หรือ Dump File เพิ่มเติม | Collect Event Viewer information or Dump files. |
| Physical damage / Liquid spilled | ตรวจสอบว่ามีความเสียหายหรือของเหลวหกใส่หรือไม่ | Check for physical damage or liquid damage. |
| Other issue | ตรวจสอบว่ามีอาการอื่นเพิ่มเติมหรือไม่ | Check whether there is any other issue. |
| FRU P/N | Do not include in customer email by default. | Do not include in customer email by default. |

## v4.9.4 Approved Email Mapping Additions

| Checklist | Customer Visible | Action Type | Evidence | Email TH | Email EN |
|---|---:|---|---|---|---|
| Emergency Reset | Yes | Action | None | ทดสอบ Emergency Reset โดยกดรูใต้เครื่องค้างไว้ 5–10 วินาที จากนั้นทดลองเปิดเครื่องอีกครั้ง | Test Emergency Reset by pressing the reset hole on the bottom cover for 5–10 seconds, then power on the machine again. |
| Power Reset | Yes | Action | None | ทดสอบ Power Reset โดยกดปุ่มเปิด/ปิดเครื่องค้างไว้ 10–15 วินาที จากนั้นตรวจสอบอาการอีกครั้ง | Test Power Reset by holding the power button for 10–15 seconds, then check the issue again. |
| Run Lenovo Diagnostics | Yes | Action / Result | Screenshot / Result | ทดสอบ Run Diagnostics\nสำหรับ ThinkPad, ThinkCentre Desktop, ThinkCentre Tiny และ AIO: กด F10 รัว ๆ ขณะเปิดเครื่อง → เลือก Run All → Quick → Quick Unattended จากนั้นตรวจสอบว่า Pass หรือ Failed\nสำหรับ IdeaPad: กด Novo Button → เลือก UEFI Diagnostics → Run All → Quick จากนั้นตรวจสอบว่า Pass หรือ Failed | Run Lenovo Diagnostics.\nFor ThinkPad, ThinkCentre Desktop, ThinkCentre Tiny, and AIO: press F10 repeatedly while turning on the machine → select Run All → Quick → Quick Unattended, then check whether the result is Pass or Failed.\nFor IdeaPad: press the Novo Button → select UEFI Diagnostics → Run All → Quick, then check whether the result is Pass or Failed. |
| Battery Health in Lenovo Vantage | Yes | Verify | Screenshot | รบกวนตรวจสอบ Battery Health\nโดยเปิด Lenovo Vantage > Device > Battery Health | Please check Battery Health in Lenovo Vantage. |
| Check Camera in Device Manager | Yes | Verify | Optional Screenshot | ตรวจสอบว่า Device Manager พบอุปกรณ์ Camera หรือไม่\nโดยเปิด Device Manager > Cameras | Check whether Device Manager detects the Camera device. |
| Check Fingerprint Device in Device Manager | Yes | Verify | Optional Screenshot | ตรวจสอบว่า Device Manager พบอุปกรณ์ Fingerprint หรือไม่\nโดยเปิด Device Manager > Biometric Devices | Check whether Device Manager detects the Fingerprint device. |
| Check HID-compliant touch screen Driver in Device Manager | Yes | Verify | Optional Screenshot | ตรวจสอบว่า Device Manager พบ HID-compliant touch screen หรือไม่\nโดยเปิด Device Manager > Human Interface Devices | Check whether Device Manager detects HID-compliant touch screen. |
| Check Wireless Driver in Device Manager | Yes | Verify | Optional Screenshot | ตรวจสอบว่า Device Manager พบอุปกรณ์ Wireless หรือไม่\nโดยเปิด Device Manager > Network adapters | Check whether Device Manager detects the Wireless device. |
| FRU P/N | Yes, but do not mention FRU | Send Photo | Photo | รบกวนส่งภาพถ่ายสติกเกอร์ Serial Number / MTM ที่อยู่ใต้เครื่องหรือด้านหลังเครื่อง | Please send a photo of the Serial Number / MTM sticker on the bottom or rear side of the machine. |
| Event Viewer / Dump file collected | No | Internal / Engineer Only | File | - | - |
| Other issue | No | Internal Only | None | - | - |
