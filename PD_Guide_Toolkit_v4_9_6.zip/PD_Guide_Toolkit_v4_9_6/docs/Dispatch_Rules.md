# Dispatch / Review Rules

## Core rules
- Use Part or อะไหล่ when referring to the item to dispatch.
- FRU means the part number only.
- Customer First: checklist items must be actions a customer can perform remotely with an Agent.
- Evidence First: dispatch must be based on evidence, not only on Same Issue count.
- One case should recommend only one Part.
- Email TH / EN is a customer troubleshooting template and does not depend on selected dropdown answers.

## Symptom Recommendation Engine
If the selected symptom conflicts with checklist evidence, show a recommended symptom instead of dispatching.

Examples:
- Boot → Power On No Display + Power LED = No -> Result: Select "No power".
- Boot → No Power + Power LED = Yes -> Result: Select "Power on no display".
- Display symptom + External Monitor test = Same Issue -> Result: Select "Power on no display".
- Power LED = No + Caps Lock Toggle = Yes -> Result: Verify Checklist.

## Power on no display
Required evidence:
- Power LED
- External Monitor test
- Power Reset / Emergency Reset

Supporting evidence:
- Caps Lock Toggle
- Display Backlight
- Fan spinning

Not Tested on supporting evidence must not block dispatch when required evidence is complete.


## v4.9.1 Checklist Order
For driver/device issues, show Device Manager detection before driver uninstall/restart.


## v4.9.1 Model & Symptom Validation

Checklist items must match the selected model and symptom. Port troubleshooting must use the matching cable/adapter/driver for the selected interface, such as USB-C Display using USB-C cable and DisplayPort using DisplayPort cable.

## v4.9.3 Standard Workflow / Checklist Audit

Checklist ordering must follow `docs/STANDARD_WORKFLOW.md`.
Dispatch logic must not depend on irrelevant checklist items copied from another model or symptom.
Every dispatch-related checklist item must match the selected model and symptom.


## v4.9.6 Global Mapping Maintenance Rule

- `Mapping.txt` is the source of truth for reusable checklist action wording.
- Every release ZIP must contain `Mapping.txt` at the root and `Reference_Text/Mapping.txt`.
- Runtime must include the same mapping in `data.js` as `GLOBAL_CHECKLIST_MAPPING`.
- Any checklist label that exists in Mapping.txt must use the mapped wording for Email TH / Email EN / action guidance.
- When a new mapping is added, update Mapping.txt, Reference_Text/Mapping.txt, `GLOBAL_CHECKLIST_MAPPING`, `docs/GLOBAL_CHECKLIST_MAPPING.md`, and run full checklist audit before release.
- Audit must check duplicate labels, missing mapping, wrong model checklist, Power Reset / Emergency Reset placement, Event Viewer / Dump file placement, and FRU P/N final placement.
