# Power Reset Matrix

This file is the source of truth for where `Power Reset` is allowed in the PD Guide Toolkit.

## Release Audit Rule

Before every version release, perform a Full Project Audit.

- Do not modify only the requested checklist.
- Review all related checklists, affected models, and affected symptoms.
- A version must not be released until the audit is complete.
- If a symptom is listed below and does not contain `Power Reset`, the audit fails.
- If a symptom is not listed below but contains `Power Reset`, the audit fails.

## Power Reset must be included only in these symptoms

### Boot
- No power
- Power on no display
- Power on no display + Beep Sound
- Boot loop
- Stuck Lenovo Logo
- Stuck Automatic Repair

### Windows
- Freeze
- Black screen after login

### Display
- Black screen
- Touchscreen not work

### Battery
- Not Charge
- Battery not detect / not keep power
- Slow charge

### Port
- USB-C Thunderbolt
- USB-C Data
- USB-C Display
- USB-A
- HDMI
- SD Card
- Smart Card

### Keyboard
- All key
- Keyboard auto type
- Hotkey

### Fan
- Fan Error
- Fan Not Spin

## Power Reset must be removed from all other symptoms

Examples include, but are not limited to:

- Windows: Auto shutdown, Auto reboot
- Display: Flickering, Abnormal line, Dim, Color bias, Ghost image, Dead pixel, Bright pixel, Garbage
- Mouse / Touchpad: all symptoms
- Network: all symptoms
- Audio: all symptoms
- Camera: all symptoms
- Storage: all symptoms
- Battery: Battery runtime short, Battery swollen
- Fan: Fan Noise, Fan Spin High, Fan Overheat

## Emergency Reset Rule

For ThinkPad only, `Emergency Reset` is allowed only in:

- No power
- Power on no display
- Power on no display + Beep Sound

For all other ThinkPad symptoms, do not include `Emergency Reset`. If a reset is required and the symptom is allowed by this matrix, use only `Power Reset`.

## Placement Rule

`Power Reset` must follow the Standard Troubleshooting Workflow:

- After software/driver/update items such as Windows Update, Lenovo Vantage Update, BIOS Update
- Before BIOS setting checks, Lenovo Diagnostics, swap tests, reinstall Windows, Event Viewer / Dump file, Physical damage / Liquid spilled, Other issue, and FRU P/N
