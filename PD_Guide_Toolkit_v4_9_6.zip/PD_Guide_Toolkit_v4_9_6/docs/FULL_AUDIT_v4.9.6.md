# FULL_AUDIT_v4.9.6

## Scope

Performed a standardization audit based on v4.9.5 and prepared v4.9.6.

## Completed Changes

- Updated visible UI version to `Version 4.9.6`.
- Updated cache-busting references to `v=4_9_6`.
- Added `docs/CHECKLIST_STANDARD.md` as the standard terminology source.
- Standardized Windows reinstallation checklist label to `Re-install Windows`.
- Retained legacy alias support for older data labels: `Reinstall Windows` and `Windows Installation` map to `Re-install Windows`.
- Standardized checklist display label for diagnostics to `Run Lenovo Diagnostics` where checklist labels used the old `Lenovo Diagnostics` label.
- Corrected reset order so `Power Reset` appears before `Emergency Reset` when both are present.
- Updated ordering logic so internal hardware swap items (`Swap RAM`, `Swap SSD`, `Swap HDD`, `Swap SSD / HDD`) are placed after OS recovery / `Re-install Windows` and before final evidence/damage/other checks.
- Preserved external/easy swap checks such as `Swap Adapter`, `Swap AC Power Cord`, `Adapter Test on Other Machine`, and `USB Keyboard Test` in their normal early workflow positions.
- Added documentation rule that any Mapping or terminology change must update the Mapping files every time.

## Items to Continue Auditing in Future Versions

- Review whether `Windows Installation USB recreated` should remain as-is or be renamed to a clearer approved standard such as `Re-create Windows Installation USB`. This was not changed because it refers to USB media, not the Windows reinstall action itself.
- Review combined labels such as `Swap SSD / HDD` for possible split into separate `Swap SSD` and `Swap HDD` checklist items after approval.
- Continue checking that all Email TH / Email EN output uses Mapping text and blank-line formatting.


## Lenovo Diagnostics Mapping Audit Patch

- แก้ `Lenovo Diagnostics` และ `Run Lenovo Diagnostics` ให้ดึงข้อความจาก Mapping กลาง ไม่ใช้ข้อความ `ตรวจสอบหัวข้อ Lenovo Diagnostics`
- อัปเดต TH/EN Mapping ให้มีขั้นตอนแยกตาม Model: ThinkPad / ThinkCentre Desktop / ThinkCentre Tiny / AIO ใช้ F10 และ IdeaPad ใช้ Novo Button > UEFI Diagnostics
- อัปเดต `Mapping.txt` และ `Reference_Text/Mapping.txt` ให้ตรงกัน
- ลบ Mapping ที่ถูกสร้างผิดจากบรรทัดขั้นตอน F10/Novo Button
- ตรวจ Email TH/EN ให้แสดงข้อความจาก Mapping พร้อมเว้นบรรทัดตามมาตรฐาน

## v4.9.6 Diagnostics Model-Specific Mapping Patch
- Run Lenovo Diagnostics / Lenovo Diagnostics Storage / Lenovo Diagnostics Battery must render only the currently selected product model flow.
- IdeaPad uses Novo Button → UEFI Diagnostics → Run All → Quick.
- ThinkPad, ThinkCentre Desktop, ThinkCentre Tiny, and AIO use F10 → Run All → Quick → Quick Unattended.
- Email TH, Email EN, checklist-generated notes, copy guide, and related guide modal must not display all model instructions together.

