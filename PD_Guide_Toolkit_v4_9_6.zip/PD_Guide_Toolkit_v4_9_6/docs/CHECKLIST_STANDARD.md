# CHECKLIST_STANDARD.md

Version: v4.9.6

This file is the checklist terminology and order standard for PD Guide Toolkit.

## Approved Standard Terms

| Category | Standard Name | Notes |
|---|---|---|
| Reset | Power Reset | Must appear before Emergency Reset when both are present. |
| Reset | Emergency Reset | Only used where the model/symptom supports it. |
| Windows / OS | Re-install Windows | Approved standard term for installing Windows again. Do not use Reinstall Windows, Windows Installation, Windows Install, or Install Windows as checklist labels. |
| Diagnostics | Run Lenovo Diagnostics | Standard checklist label for Lenovo hardware diagnostics. |
| Update | Windows Update | Standard update checklist label. |
| Update | Lenovo Vantage Update | Standard update checklist label. |
| Update | BIOS Update | Standard update checklist label. |
| External Hardware Isolation | Swap Adapter | External/easy swap; can appear early for Adapter or Charging symptoms. |
| External Hardware Isolation | Swap AC Power Cord | External/easy swap; can appear early for Adapter symptoms. |
| External Hardware Isolation | Adapter Test on Other Machine | External/easy test; can appear early for Adapter symptoms. |
| External Hardware Isolation | USB Keyboard Test | External/easy keyboard isolation; can appear before software tail. |
| Internal Hardware Swap | Swap RAM | Hard/internal step; keep near the end after software/OS recovery unless a symptom has a clear technical exception. |
| Internal Hardware Swap | Swap SSD | Hard/internal step; keep near the end after software/OS recovery unless a symptom has a clear technical exception. |
| Internal Hardware Swap | Swap HDD | Hard/internal step; keep near the end after software/OS recovery unless a symptom has a clear technical exception. |
| Evidence | Event Viewer / Dump file collected | Use this exact capitalization. |
| Damage | Physical damage / Liquid spilled | Keep near the end. |
| Other | Other issue | Keep near the end. |
| Part | FRU P/N | Keep as final item when applicable. |

## Checklist Order Standard

1. Symptom confirmation and easy visual checks
2. External/easy isolation tests that do not require opening the machine
3. Software and driver actions
4. BIOS / firmware actions
5. Power Reset
6. Emergency Reset, immediately after Power Reset when both are present
7. BIOS setting checks
8. Run Lenovo Diagnostics
9. OS recovery / Re-install Windows
10. Internal hardware swap steps: Swap RAM, Swap SSD, Swap HDD
11. Event Viewer / Dump file collected
12. Physical damage / Liquid spilled
13. Other issue
14. FRU P/N

## Change Control

Before changing any standard checklist term, list the proposed terminology changes for user approval first. After approval, update Mapping.txt, Reference_Text/Mapping.txt, data.js, app.js, and all related docs together.
