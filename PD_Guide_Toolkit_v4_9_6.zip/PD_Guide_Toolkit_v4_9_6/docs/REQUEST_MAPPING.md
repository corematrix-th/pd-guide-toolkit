# PD Guide Toolkit - Request / Evidence Mapping

## Purpose

This file defines what evidence should be requested from the customer when generating Email TH / Email EN.
Evidence must be requested only when it has diagnostic value.

---

## Evidence Types

- None
- Photo
- Screenshot
- Video
- File
- Result
- Internal Only

## Evidence Priority

- Required
- Optional
- Engineer Only
- Internal Only

---

## Do Not Request Evidence For Routine Actions

Do not request screenshots or photos for these routine troubleshooting steps:

- Windows Update
- Lenovo Vantage Update
- BIOS Update
- Driver Update
- Power Reset
- Emergency Reset
- Swap Test
- Re-install Windows

The customer should only report the result unless additional evidence is specifically required.

---

## Required Photo

Use Photo when the physical condition or visual symptom must be seen.

| Symptom / Checklist | Evidence | Priority | Customer Wording |
|---|---|---:|---|
| Display abnormal line / Abnormal line | Photo | Required | รบกวนส่งภาพถ่ายหน้าจอขณะเกิดอาการ |
| Flickering | Photo / Video | Required | รบกวนส่งภาพถ่ายหรือคลิปวิดีโอขณะเกิดอาการ |
| Dead pixel | Photo | Required | รบกวนส่งภาพถ่ายหน้าจอขณะเกิดอาการ |
| Bright pixel | Photo | Required | รบกวนส่งภาพถ่ายหน้าจอขณะเกิดอาการ |
| Color bias | Photo | Required | รบกวนส่งภาพถ่ายหน้าจอขณะเกิดอาการ |
| Ghost image | Photo | Required | รบกวนส่งภาพถ่ายหน้าจอขณะเกิดอาการ |
| Physical damage / Liquid spilled | Photo | Required if present | รบกวนส่งภาพถ่ายบริเวณที่พบความเสียหาย หรือบริเวณที่มีของเหลวสัมผัสเครื่อง (ถ้ามี) |
| Battery swollen | Photo | Required | รบกวนส่งภาพถ่ายบริเวณที่ตัวเครื่องโก่งนูน |
| FRU P/N | Photo | Required when part identification is needed | รบกวนส่งภาพถ่ายสติกเกอร์ Serial Number / MTM ที่อยู่ใต้เครื่องหรือด้านหลังเครื่อง |

---

## Required Screenshot

Use Screenshot when the result is on screen and helps diagnosis.

| Symptom / Checklist | Evidence | Priority | Customer Wording |
|---|---|---:|---|
| Device Manager Check | Screenshot | Optional | รบกวนส่งภาพหน้าจอ Device Manager หากพบความผิดปกติ |
| Run Lenovo Diagnostics | Screenshot / Result | Required | รบกวนส่งภาพหน้าจอผลการทดสอบ Lenovo Diagnostics |
| Battery Health | Screenshot | Required | รบกวนส่งภาพหน้าจอ Battery Health จาก Lenovo Vantage |
| Error Code | Screenshot / Photo | Required | รบกวนส่งภาพหน้าจอหรือภาพถ่าย Error Code ที่พบ |
| BSOD | Screenshot / Photo | Required | รบกวนส่งภาพหน้าจอหรือภาพถ่าย Stop Code ที่พบ |
| BIOS Setting | Screenshot / Photo | Optional | รบกวนส่งภาพหน้าจอ BIOS เฉพาะกรณีจำเป็น |

---

## Required Video

Use Video when still photos are not enough.

| Symptom | Evidence | Priority | Customer Wording |
|---|---|---:|---|
| Fan Noise | Video | Required | รบกวนส่งคลิปวิดีโอขณะเกิดอาการ |
| Speaker Noise | Video | Required | รบกวนส่งคลิปวิดีโอขณะเกิดอาการ |
| Auto reboot | Video | Optional | รบกวนส่งคลิปวิดีโอขณะเกิดอาการ หากสามารถบันทึกได้ |
| Freeze | Video | Optional | รบกวนส่งคลิปวิดีโอขณะเกิดอาการ หากสามารถบันทึกได้ |
| Keyboard auto type | Video | Required | รบกวนส่งคลิปวิดีโอขณะเกิดอาการ |
| Cursor / Jump | Video | Required | รบกวนส่งคลิปวิดีโอขณะเกิดอาการ |
| Intermittent issue | Video | Optional | รบกวนส่งคลิปวิดีโอขณะเกิดอาการ หากสามารถบันทึกได้ |

---

## File / Engineer Request

Do not request these files by default unless an engineer specifically asks.

| Checklist | Evidence | Priority |
|---|---|---:|
| Event Viewer / Dump file collected | File | Engineer Only |
| Dump File collected | File | Engineer Only |
| MSInfo32 | File | Engineer Only |
| DxDiag | File | Engineer Only |

---

## Internal Only

Never show these as raw checklist items in customer email:

- Dispatch
- Conclusion
- Suggested PD
- Other issue
- FRU P/N
- Event Viewer / Dump file collected
- Dump File collected


## v4.9.6 Global Mapping Maintenance Rule

- `Mapping.txt` is the source of truth for reusable checklist action wording.
- Every release ZIP must contain `Mapping.txt` at the root and `Reference_Text/Mapping.txt`.
- Runtime must include the same mapping in `data.js` as `GLOBAL_CHECKLIST_MAPPING`.
- Any checklist label that exists in Mapping.txt must use the mapped wording for Email TH / Email EN / action guidance.
- When a new mapping is added, update Mapping.txt, Reference_Text/Mapping.txt, `GLOBAL_CHECKLIST_MAPPING`, `docs/GLOBAL_CHECKLIST_MAPPING.md`, and run full checklist audit before release.
- Audit must check duplicate labels, missing mapping, wrong model checklist, Power Reset / Emergency Reset placement, Event Viewer / Dump file placement, and FRU P/N final placement.


## v4.9.6 Mapping Email Refactor Audit
- Added missing checklist labels into Mapping.txt and Reference_Text/Mapping.txt.
- Total runtime mapping entries: 246.
- Email TH and Email EN now call GLOBAL_CHECKLIST_MAPPING first before fallback rules.
- Verified Power LED / Charge LED / Adapter / Reset email text uses Mapping.txt wording instead of hardcoded wording.
