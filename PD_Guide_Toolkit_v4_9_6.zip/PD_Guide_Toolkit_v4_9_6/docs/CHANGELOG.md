## v4.9.6

- Added root `Mapping.txt` and `Reference_Text/Mapping.txt` to the release package.
- Added runtime `GLOBAL_CHECKLIST_MAPPING` in `data.js`.
- Added `docs/GLOBAL_CHECKLIST_MAPPING.md`.
- Added v4.9.6 full audit report.
- Updated checklist mapping rules so mapped checklist labels are reused across Email TH / Email EN / action guidance.
- Normalized common checklist aliases and tail ordering.
- Updated visible version label to 4.9.5.

## v4.9.3

- Performed Full Project Audit pass before release.
- Added `docs/STANDARD_WORKFLOW.md`.
- Added Standard Troubleshooting Workflow rule.
- Added FRU P/N placement rule: FRU P/N must always be last.
- Added No power adapter rule: if Swap Adapter exists, remove duplicate Swap AC Power Cord.
- Added ThinkPad Reset Rule: Emergency Reset only appears in ThinkPad Boot > No power / Power on no display / Power on no display + Beep Sound.
- Updated port checklists so cable / monitor actions match the selected symptom, including USB-C Display, HDMI, DisplayPort, and VGA.
- Removed Emergency Reset from non-allowed ThinkPad symptoms.
- Standardized Device Manager wording and ordering before driver uninstall.
- Updated version number to 4.9.3.

## v4.9.1

- Added File Naming Rule: when modifying the same version, keep the exact filename and do not append suffixes.
- Added Model & Symptom Validation Rule to prevent checklist items from being copied across incompatible models, ports, or symptoms.
- Updated Port > USB-C Display checklist to match direct USB-C to monitor usage.
- Updated Port > DisplayPort checklist to use DisplayPort-specific troubleshooting instead of HDMI cable checks.

## v4.9.0

- Standardized all Device Manager checklist labels to `Check <Device Name> in Device Manager`.
- Added rule: `Check <Device Name> in Device Manager` must appear before `Uninstall <Device Name> Driver and Restart`.
- Updated `Touchscreen not work` checklist.
- Removed `Monitor` level from ThinkPad / IdeaPad / AIO model structures and Reference_Text.
- Kept `Monitor` only for ThinkCentre Desktop and ThinkCentre Tiny.
- Changed all Beep wording to `Power on no display + Beep Sound`.
- Updated ThinkCentre Tiny `No power` checklist: remove Power Outlet and PSU, use `Swap AC Power Cord`.
- Added `FRU P/N` to ThinkCentre Tiny keyboard symptoms.
- Added `Swap Audio Jack Port` to Front/Rear Audio Jack.
- Added `Test Tiny without TIO Dock` to TIO Dock not charging/no power checklist.

# Changelog

## v4.8.9

- Added new troubleshooting guides: Reset Battery, LCD Self-Test, Disable Audio Enhancements (External Microphone), ThinkCentre RAID 1 SSD Not Found During OS Installation, Fn & Ctrl Key Swap.
- Updated Reset this PC WinRE instructions using repeated force shutdown method.
- Added related guides for Microphone Low Sound and Keyboard Left Ctrl.
- Added related Reset Battery under Battery Health workflow.
- Added Generate Note lowercase checklist rule with technical-term exceptions and FRU P/N uppercase rule.
- Split ThinkPad Power Reset and Emergency Reset checklist items.
- Added Software / Driver / BIOS update mapping with done / not test options.

## v4.8.6
- Major logic audit across symptoms using Evidence First / Customer First rules.
- Added Symptom Recommendation and accessory suggestion handling for Power Cord, Adapter, HDMI Cable, DisplayPort Cable, USB-C Cable and LAN Cable.
- Fixed Desktop/AIO No Power logic: Swap Power Cable = Working now dispatches Power Cord.
- Added Port > Not Charge alias using the same checklist and logic as Battery > Not Charge.
- Blank Result now shows No default next-step text in Generate Note.
- Revised Checklist Priority Rule: Not Tested blocks dispatch only for required evidence; optional/recommended checks such as Lenovo Diagnostics, Caps Lock Toggle, Display Backlight and supporting Fan checks no longer block dispatch when clear evidence exists.
- Fixed Fan Error logic: Lenovo Diagnostics is optional; BIOS Update = Same Issue + Load BIOS Default = Same Issue can dispatch Fan when no damage/other issue is present.
- ZIP packaging keeps one root folder and backup stores only the previous version.

# PD Guide Toolkit Changelog

## v4.8.6
- Added Symptom Recommendation Engine.
- Added Checklist Priority Rule: optional checks such as Caps Lock Toggle should not block dispatch when required evidence is complete.
- Smart Review applies to Generate Note only.
- Email TH / EN remains available and uses the full customer checklist template for the selected symptom.
- Result / Email keeps checklist summary at the top and shows Review only when needed.
- ZIP packaging includes the main folder to prevent extracted files from scattering.


## v4.8.6 Revision
- Removed default Continue Troubleshooting from Conclusion and Generate Note. If the system cannot determine a part, Result and Part are left blank.
- Review still appears for inconsistent information only.
- Renamed Windows Camera App to Camera and Voice Recorder test to Voice Recorder.

### v4.8.6 revision
- Result / Email now shows only one compact line for normal cases, e.g. `Conclusion: Dispatch Mainboard`.
- Removed duplicated Result / Part from Result / Email output.
- Hidden Suggested PD in normal Dispatch/FOP cases.
- Symptom recommendations now use full menu path with arrow format, e.g. `Display → Black Screen`.
- Added Power On No Display rule: Power LED = Yes + Caps Lock Toggle = No + External Monitor = Same Issue → Dispatch Mainboard.
- Result / Email now always includes `Conclusion:`.
- If a part cannot be determined, Result / Email shows `Conclusion:` only.
- Inconsistent Review and Symptom Suggestion blocks also end with blank `Conclusion:`.
- Removed Power Reset auto-review text; FOP now uses the normal compact conclusion format.

- v4.9.1 hotfix: standalone checklist label "Camera" must not be used; replace with "Check Camera in Device Manager". Device Manager camera check remains "Check Camera in Device Manager".

## v4.9.1 Full Audit correction
- Applied Full Audit rule for port checklists.
- Fixed ThinkCentre Desktop / ThinkCentre Tiny > Port > VGA from `Swap HDMI cable` to `Swap VGA cable`.
- Standardized port display checklists to use `Swap Monitor` where the intent is to test another monitor.
- Re-applied Device Manager label pattern across source text: `Check <Device Name> in Device Manager`.
- Fixed ThinkCentre Desktop / ThinkCentre Tiny > Port > Serial Port so it no longer reuses USB-A troubleshooting wording.

## v4.9.3 Power Reset Matrix Audit Update

- Added `docs/POWER_RESET_MATRIX.md` as the source of truth for Power Reset / Emergency Reset placement.
- Added Power Reset Matrix Rule to `DEVELOPMENT_RULES.md`.
- Applied Full Project Audit enforcement to add Power Reset only to the approved symptom matrix.
- Removed Power Reset from symptoms outside the approved matrix.
- Preserved Emergency Reset only for ThinkPad Boot > No power, Power on no display, and Power on no display + Beep Sound.
- Preserved FRU P/N as the last checklist item.



## v4.9.3 Final Power Reset Matrix + Workflow Audit

- Updated `POWER_RESET_MATRIX.md` with the final approved Power Reset symptom list.
- Enforced Power Reset only on approved symptoms.
- Removed Power Reset from Auto shutdown, Auto reboot, Flickering, Mouse/Touchpad, Network, Audio, Camera, Storage, and other non-approved symptoms.
- Updated Event Viewer / Dump file placement to appear before Physical damage / Liquid spilled.
- Added Full Project Audit release rule to development documentation.


## v4.9.3

- Performed Full Project Audit across all models, symptoms, and checklist rules.
- Added `docs/EMAIL_RULES.md` for customer Email TH / EN writing style and checklist-to-email mapping.
- Updated version label to 4.9.3.
- Enforced final Power Reset Matrix and Emergency Reset placement.
- Enforced Event Viewer / Dump file collected position before Physical damage / Liquid spilled.
- Enforced FRU P/N as the final checklist item.
- Removed duplicate Device Manager checklist labels and standardized Device Manager wording.
- Updated email generation to use customer-friendly Thai and English instructions.

## v4.9.3 Email TH/EN hotfix
- Fixed Email TH / Email EN generation so buttons populate customer email content correctly.
- Prevented Email customer-step fallback recursion when a checklist label has no predefined email mapping.

## v4.9.3 Email Full Audit Update

- Reworked Email TH / Email EN generation to use customer-facing instruction mapping instead of raw checklist labels.
- Added `docs/EMAIL_MAPPING.md`.
- Updated `docs/EMAIL_RULES.md` with short imperative writing style, Device Manager wording, Swap wording, and audit requirements.
- Updated `docs/DEVELOPMENT_RULES.md` with Email Generation Rule.
- Ensured FRU P/N is excluded from customer emails by default.

## v4.9.4

- Full Project Audit for Email TH / Email EN generation.
- Added `REQUEST_MAPPING.md` for evidence requests: Photo, Screenshot, Video, File, Result, None, and Internal Only.
- Updated `EMAIL_RULES.md` with customer action types, evidence rules, and Device Manager category pattern.
- Updated Email TH / EN mapping for Emergency Reset, Power Reset, Lenovo Diagnostics, Battery Health, and Device Manager checks.
- Standardized reset email wording:
  - Emergency Reset: press reset hole under the machine for 5–10 seconds.
  - Power Reset: hold power button for 10–15 seconds.
- FRU P/N is no longer written as an FRU request to customers; it is converted into a Serial Number / MTM sticker photo request.
- Routine updates and swap tests no longer request screenshots by default.


## v4.9.6 Mapping Email Refactor Audit
- Added missing checklist labels into Mapping.txt and Reference_Text/Mapping.txt.
- Total runtime mapping entries: 246.
- Email TH and Email EN now call GLOBAL_CHECKLIST_MAPPING first before fallback rules.
- Verified Power LED / Charge LED / Adapter / Reset email text uses Mapping.txt wording instead of hardcoded wording.


## v4.9.6 Lenovo Diagnostics Mapping Patch
- Fixed Lenovo Diagnostics TH/EN output to use central Mapping text.
- Replaced generic `ตรวจสอบหัวข้อ Lenovo Diagnostics` with the approved model-specific diagnostics instructions.
- Synced `Mapping.txt`, `Reference_Text/Mapping.txt`, runtime `GLOBAL_CHECKLIST_MAPPING`, and related guide text.

## v4.9.6 Diagnostics Model-Specific Mapping Patch
- Run Lenovo Diagnostics / Lenovo Diagnostics Storage / Lenovo Diagnostics Battery must render only the currently selected product model flow.
- IdeaPad uses Novo Button → UEFI Diagnostics → Run All → Quick.
- ThinkPad, ThinkCentre Desktop, ThinkCentre Tiny, and AIO use F10 → Run All → Quick → Quick Unattended.
- Email TH, Email EN, checklist-generated notes, copy guide, and related guide modal must not display all model instructions together.

