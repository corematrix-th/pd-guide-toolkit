# Global Checklist Mapping (v4.9.6)

`Mapping.txt` is now the source of truth for reusable checklist wording.

## Required rule

Every release ZIP must include:

- `Mapping.txt` at toolkit root
- `Reference_Text/Mapping.txt`
- Runtime copy in `data.js` as `GLOBAL_CHECKLIST_MAPPING`

When a new mapping is added, update all three places and re-run checklist audit.

## Mapping entries imported

### Power LED
ตรวจสอบว่าไฟสถานะที่ปุ่มเปิด/ปิดติดหรือไม่

### Charge LED
ตรวจสอบว่าไฟสถานะบริเวณช่องชาร์จติดหรือไม่

### Swap Adapter
ทดสอบสลับ Adapter อื่น ๆ

### Swap other Type-C port
ทดสอบสลับช่องชาร์จ (Type-C) ช่องอื่น

### Adapter test on other machine
ทดสอบนำ Adapter ไปทดสอบกับเครื่องอื่น

### Power Reset
ทดสอบเคลียร์ไฟ (Power reset) โดยสายชาร์จออก จากนั้นกดปุ่ม Power ค้างไว้ประมาณ 30 วินาที แล้วลองเปิดเครื่องใหม่อีกครั้ง

### Emergency Reset
ทดสอบ Reset Battery โดยจิ้มรูที่ใต้ตัวเครื่องประมาณ 5-10 วินาที จากนั้นเปิดเครื่องใหม่

### Physical damage / Liquid spilled
ตัวเครื่องมีรอยชำรุด เสียหาย หรือมีประวัติน้ำหกใส่หรือไม่

### Other issue
ตัวเครื่องมีอาการผิดปกติอื่น ๆ เพิ่มเติมหรือไม่

### Fan spinning
ตรวจสอบพัดลมหมุนหรือไม่

### Caps Lock Toggle
ทดสอบกดปุ่ม Caps Lock ดูว่าไฟตอบสนองไหม

### External Monitor test
กรณีจอ notebook ไม่มีภาพ > ทดสอบต่อจอนอกและตรวจสอบว่าภาพออกหรือไม่
กรณีจอเสีย หรือเป็นเส้น > ทดสอบต่อจอนอกและตรวจสอบว่าพบปัญหาเดียวกันหรือไม่

### Display Backlight
ตรวจสอบว่ามีแสงสว่างจากหลังหน้าจอหรือไม่

### Beep sound / pattern
รบกวนส่งคลิปถ่ายเสียงร้องเตือน (Beep sound) เพื่อตรวจสอบเพิ่มเติม

### Swap RAM
ทดสอบสลับ RAM ตัวอื่น

### Swap SSD
ทดสอบสลับ SSD ตัวอื่น

### Swap HDD
ทดสอบสลับ HDD ตัวอื่น

### Can access Windows
สามารถเข้าหน้า Windows ได้หรือไม่

### Can boot into BIOS
สามารถเข้าหน้า BIOS ได้หรือไม่

### Can boot into Safe Mode
สามารถเข้าหน้า Safe Mode ได้หรือไม่

### Lenovo Diagnostics
Thinkpad, TC Desktop, TC Tiny, AIO > ทดสอบ Run Diagnostics
โดย F10 รัว ๆ ขณะเปิดเครื่อง →  เลือก Run All → Quick → Quick Unattended จากนั้นตรวจสอบว่า Pass หรือ Failed

### Idepad > ทดสอบ Run Diagnostics
โดยกด Novo Button > เลือก UEFI Diagnostics → Run All → Quick จากนั้นตรวจสอบว่า Pass หรือ Failed

### BIOS detects storage
ตรวจสอบหน้า Bios พบ SSD/HDD หรือไม่

### Re-install Windows
รบกวนทดสอบติดตั้ง windows ใหม่

### System Restore
ทดสอบ System Restore
โดยเข้าหน้า Choose an option → Advanced options → Troubleshoot → Reset This PC → เลือก Keep my files หรือ Remove everything → ทำตามขั้นตอนบนหน้าจอจนเสร็จสิ้น

### Check Task Manager Usage
เข้าหน้า Task Manager และตรวจสอบการทำงานของเครื่อง เช่น CPU/RAM/DISK วิ่ง 100% หรือไม่

### Slow occurs / Freeze occurs
พบอาการเครื่องช้าหรือค้างตอนไหนบ้าง

### Auto reboot occurs
พบอาการเครื่อง Restart ช่วงใดบ้าง

### BSOD occurs
พบอาการจอฟ้า (BSOD) ช่วงใดบ้าง

### Stop code / Error code collected
รบกวนส่งภาพถ่าพ Error code หรือ Stop code เพื่อตรวจสอบเพิ่มเติม

### Windows update
ทดสอบอัปเดต Windows ให้เป็นเวอร์ชันล่าสุด

### Lenovo Vantage Update
ทดสอบอัปเดตไดรเวอร์ทั้งหมดผ่านโปรแกรม Lenovo Vantage
โดยเปิด Lenovo Vantage → ไปที่ System Update → กด Check for updates

### XXX Driver Update
ทดสอบอัปเดตไรเวอร์ที่มีปัญหา

### BIOS Update
ทดสอบอัปเดต BIOS ให้เป็นเวอร์ชันล่าสุด

### Check temperature / Overheat
ตรวจสอบอุณหภูมิของตัวเครื่องพบปัญหาเครื่องร้อนหรือไม่ และบริเวณใด

### Event Viewer / Dump file collected
รบกวนส่ง Dump file เพื่อตรวจสอบเพิ่มเติม
โดยเปิด File Explorer → C:\Windows\Minidump → จากนั้น Copy ไฟล์ .dmp และส่งมาทางอีเมลนี้
หากไม่มีไฟล์ ให้ไปที่ C:\Windows\MEMORY.DMP



## v4.9.6 Mapping Email Refactor Audit
- Added missing checklist labels into Mapping.txt and Reference_Text/Mapping.txt.
- Total runtime mapping entries: 246.
- Email TH and Email EN now call GLOBAL_CHECKLIST_MAPPING first before fallback rules.
- Verified Power LED / Charge LED / Adapter / Reset email text uses Mapping.txt wording instead of hardcoded wording.
