# Standard Troubleshooting Workflow

Version: v4.9.6

This document defines the standard order for every PD Guide Toolkit troubleshooting checklist.

## Core rule

Every checklist must follow this order when the item is applicable to the selected model and symptom.
A checklist does not need to contain every item, but any included item must appear in this relative order.

```text
1. Symptom Information
   - XXX occurs
   - Specific keys listed

2. Error Code
   - Only if applicable

3. Windows / Software Setting
   - Only if applicable

4. Check XXX in Device Manager
   - Only if applicable

5. Uninstall XXX Driver and Restart
   - Only if applicable

6. XXX Driver Update
   - Only if applicable

7. Windows Update
   - Only if applicable

8. Lenovo Vantage Update
   - Only if applicable

9. BIOS Update
   - Only if applicable

10. Emergency Reset
    - ThinkPad only
    - Boot > No power
    - Boot > Power on no display
    - Boot > Power on no display + Beep Sound

11. Power Reset
    - Only if applicable

12. BIOS XXX Enabled
    - Only if applicable

13. Run Lenovo Diagnostics
    - Only if applicable

14. Swap RAM / SSD / HDD / Cable / Adapter / Monitor / Device
    - Only if applicable
    - Must match the selected model, port, and symptom

15. XXX Test on Other Machine
    - Only if applicable

16. Re-install Windows
    - Only if applicable

17. Physical damage / Liquid spilled

18. Other issue

19. Event Viewer / Dump File
    - Only if applicable

20. FRU P/N
    - Always last when present
```

## Device Manager rule

Use this pattern for all Device Manager detection checks:

```text
Check <Device Name> in Device Manager
```

The Device Manager check must always appear before the matching driver uninstall step.

Example:

```text
Check Camera in Device Manager
Uninstall Camera Driver and Restart
```

## Reset rules

### Emergency Reset

For ThinkPad, Emergency Reset is allowed only in:

```text
Boot > No power
Boot > Power on no display
Boot > Power on no display + Beep Sound
```

Do not include Emergency Reset in any other ThinkPad symptom.

### Power Reset

Power Reset should be used only when the symptom can reasonably relate to EC, power state, device initialization, or firmware state.
Do not add Power Reset to purely physical defects where it does not help isolation.

## No power adapter rule

For No power:

```text
If Swap Adapter exists, do not also ask Swap AC Power Cord.
```

## FRU P/N placement rule

`FRU P/N` is part information, not troubleshooting.
It must be placed at the end of the checklist, after `Other issue` and after log collection if present.

## Model and symptom validation

Every checklist item must match the selected:

- Product model
- Hardware architecture
- Symptom
- Port / interface
- Connection method
- Driver / device
- Replaceable component

Never reuse a checklist from another model or symptom without validating every item.

## Port / cable examples

```text
USB-C Display -> Swap USB-C Cable
HDMI -> Swap HDMI Cable
DisplayPort -> Swap DisplayPort Cable
VGA -> Swap VGA Cable
LAN -> Swap LAN Cable
Audio Jack -> Swap Audio Jack Port / Audio Device
```

## Release audit rule

Before every version release, perform a Full Project Audit.
Do not modify only the requested checklist.
Review all related checklists, affected models, and affected symptoms to ensure consistency across the toolkit.
A version must not be released until the audit is complete.


## Event Viewer / Dump File Placement Update

`Event Viewer / Dump file collected` must be placed after `Re-install Windows` and before `Physical damage / Liquid spilled`.

Standard ending order:

1. Re-install Windows
2. Event Viewer / Dump file collected (only if applicable)
3. Physical damage / Liquid spilled
4. Other issue
5. FRU P/N

## Power Reset Matrix Reference

`Power Reset` must be added or removed according to `docs/POWER_RESET_MATRIX.md`. Do not add `Power Reset` outside the approved matrix.


## v4.9.4 Event Viewer Position

`Event Viewer / Dump file collected` must be placed after `Re-install Windows` and before `Physical damage / Liquid spilled`.


## v4.9.6 Standardization Addendum

- Power Reset must appear before Emergency Reset whenever both are used.
- Emergency Reset must be directly after Power Reset.
- External/easy isolation checks such as Swap Adapter, Swap AC Power Cord, Adapter Test on Other Machine, USB Keyboard Test, and External Monitor Test may appear before software actions when technically appropriate.
- Internal hardware swaps such as Swap RAM, Swap SSD, and Swap HDD must be placed near the end, after software/BIOS/diagnostics/OS recovery steps, unless there is a documented technical exception.
- The approved checklist label for installing Windows again is `Re-install Windows`.
- The approved diagnostics checklist label is `Run Lenovo Diagnostics`.
